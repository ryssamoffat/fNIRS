%% Shiimadzu .txt to .nirs to .snirf
%
% Input:
% .txt file : Exported from Shimadzu LABNIRS, LIGHTNIRS analysis software.
%             This must be not 'Hb' but 'voltage' data.
% .sd file  : Create an .sd file for source and detector information.
%             This script doesn't use the SD.MeasList information of the
%             .sd file. Therefore, using SDgui of Homer2, input at least
%             placement information of source and detector.
% importNIRSfile :
%             Create the script to import the .txt file by [Import
%             Data] function of MATLAB and save it as "importNIRSfile.m".


close all

%% Set paths
addpath(genpath('.../Shimadzu2nirs'))
addpath(genpath('.../snirf_homer3-master'))

%% Select Imput files
% Shimadzu output Voltage .txt file.
[filename_nirs, pathname1] = uigetfile('*.TXT','Select the fNIRS voltage data file');
filename_nirs=fullfile(pathname1 ,filename_nirs);

% Select Source-Detector configuration .sd file.
[filename_sd, pathname2] = uigetfile('*.sd','Select the fNIRS SD file');
filename_sd=fullfile(pathname2 ,filename_sd);

%% Create Homer .nirs file

disp('Importing the nirs file...');
Data_raw = importNIRSfile(filename_nirs,36,Inf); % Import txt file

d = Data_raw(:,5:end); % Raw intensity data for all channels and wavelenghts

% This is to correct if there are any negative data points that cause
% errors when converting into optical density. Replace them with a
% very small positive number
for i=1:size(d,2)
    idx = find(d(:,i)<=0);
    if ~isempty(idx)
        d(idx,i)=0.0001;
    end
end

t=Data_raw(:,1); % Time

%% Make SD.MeasList from the imput files

disp('Converting to Homer2 format...');
load(filename_sd,'-mat'); % open the .sd file

fid_nirs = fopen(filename_nirs); % open the .txt file, again
if fid_nirs == -1
    disp('failed to open the nirs file for channel information');
    quit;
end
C = textscan(fid_nirs,'%s','delimiter','\n'); 
fclose(fid_nirs);
C = [C{1,1}];
list = (C{33,:});                   % get the channel information
list = regexprep(list,'"',' ');     % get rid of characters '"'
list = regexprep(list,',',' ');     % get rid of characters ','
list = regexprep(list,'(','');      % get rid of characters '('
list = regexprep(list,')',' ');     % get rid of characters ')'
list = str2num(list);               % convert to number
list = reshape(list, 2, []).';

wav=[1 2 3]';
clear SD.MeasList;
i=1;
k=1;
while i<=length(list)*3
    SD.MeasList(i:i+2,:)= [repmat(list(k,:),3,1) ones(3,1) wav];
    i=i+3;
    k=k+1;
end

SD.Lambda = [780 805 830]; % Wavelengths

%% Import the Stimuli of Event Related
stim=Data_raw(:,2); % Trigger markers in column2

Task1=find(stim==1); % Task 1
Task2=find(stim==2); % Task 2
Task3=find(stim==3); % Task 3

s=zeros(size(Data_raw,1),3); % Set Task 1 and 2 in the two columns
s(Task1,1)=1;  % Task1 Start
s(Task2,2)=1; % Task2 Start
s(Task3,3)=1; % Task2 Start

%% Save the data as .nirs

ml = SD.MeasList;
aux=ones(size(t));
disp('Saving...');
save([filename_nirs(1:end-4) '.nirs'],'t', 'd', 'SD','ml','s', 'aux');
disp('Almost done!');

%% Convert to .snirf

nirs = load([filename_nirs(1:end-4) '.nirs'],'-mat');
snirf1 = SnirfClass(nirs);
snirf1.Save([filename_nirs(1:end-4) '.snirf']);
disp('Really done!');
%snirf1.Info()

% check that file saved correctly
snirf2 = SnirfClass();
snirf2.Load([filename_nirs(1:end-4) '.snirf']);
%snirf2.Info();
